package com.cts.policyManagmentSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.policyManagmentSystem.bean.Policy;
import com.cts.policyManagmentSystem.dao.PolicyDAO;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class PolicyServiceImpl implements PolicyService {

	@Autowired
	PolicyDAO policyDAO;

	@Override
	public String addPolicy(Policy policy) {
		// TODO Auto-generated method stub
		return policyDAO.addPolicy(policy);
	}

	@Override
	public List<Policy> getAllPolicy() {
		// TODO Auto-generated method stub
		return policyDAO.getAllPolicy();
	}

	@Override
	public String updatePolicy(Policy policy) {
		// TODO Auto-generated method stub
		return policyDAO.updatePolicy(policy);
	}

	@Override
	public Policy getPolicyById(String policyId) {
		// TODO Auto-generated method stub
		return policyDAO.getPolicyById(policyId);
	}

	@Override
	public List<Policy> searchPolicyByValues(String search_by, String search_value) {
		// TODO Auto-generated method stub
		return policyDAO.searchPolicyByValues(search_by, search_value);
	}
	
	
}
