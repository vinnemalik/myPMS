package com.cts.policyManagmentSystem.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.policyManagmentSystem.bean.Policy;
import com.cts.policyManagmentSystem.bean.User;

@Repository("policyDAO")
public class PolicyDAOImpl implements PolicyDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional
	public String addPolicy(Policy policy) {
		// TODO Auto-generated method stub
		
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		session.save(policy);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public List<Policy> getAllPolicy() {
		// TODO Auto-generated method stub
		Session session = null;
		  try {
			  System.out.println("hi from getall");
	    	  	String query= "from Policy";
	    		Query<Policy> query2=null;
	    		session = sessionFactory.getCurrentSession();
	    		query2=session.createQuery(query);
	    		List<Policy> policies = query2.getResultList();
	    		if(policies==null)
	    			return null;
	    		else
	    			return policies;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
		return null;
	}

	@Transactional
	public String updatePolicy(Policy policy) {
		// TODO Auto-generated method stub
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		session.update(policy);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public Policy getPolicyById(String policyId) {
		// TODO Auto-generated method stub
		Session session = null;
		
		String query= "from Policy where policyId = ?";
		Query<Policy> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, policyId);
			Policy policy = query2.getSingleResult();
			if(policy==null)
				return null;
			else
				return policy;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public List<Policy> searchPolicyByValues(String search_by, String search_value) {
		// TODO Auto-generated method stub
		Session session =null;
		String query;
		if("By Name".equals(search_by)){
		query="from Policy where policyName=?";
		org.hibernate.query.Query<Policy> query2 = null;
		session=sessionFactory.getCurrentSession();
		query2=session.createQuery(query);
		query2.setParameter(0, search_value);
		List<Policy> list=query2.getResultList();
		return list;
		}
		else if("By Id".equals(search_by)){
	    query="from Policy where policyId=?";
	    org.hibernate.query.Query<Policy> query2 = null;
	    session=sessionFactory.getCurrentSession();
		query2=session.createQuery(query);
		query2.setParameter(0, search_value);
		List<Policy> list=query2.getResultList();
		return list;
		}
		else if("By Type".equals(search_by)){
		    query="from Policy where policyType=?";
		    org.hibernate.query.Query<Policy> query2 = null;
		    session=sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, search_value);
			List<Policy> list=query2.getResultList();
			return list;
		}
		
		else{
		query="from Policy where duration=?";
		org.hibernate.query.Query<Policy> query2 = null;
		session=sessionFactory.getCurrentSession();
		query2=session.createQuery(query);
		query2.setParameter(0, search_value);
		List<Policy> list=query2.getResultList();
		return list;
		}
	}
}
