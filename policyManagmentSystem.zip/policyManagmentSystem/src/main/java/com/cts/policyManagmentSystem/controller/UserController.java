package com.cts.policyManagmentSystem.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.policyManagmentSystem.bean.Policy;
import com.cts.policyManagmentSystem.service.PolicyService;
import com.cts.policyManagmentSystem.service.UserService;

@Controller
public class UserController {
static public List<Policy> li= new ArrayList<Policy>(); 
	@Autowired
	UserService userService;
	
	@Autowired
	PolicyService policyService;
	
	
	@RequestMapping(value="viewPolicyByUser.html")
	public ModelAndView getViewPolicy(@RequestParam("id") String id,HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		Policy policy= policyService.getPolicyById(id);
		mav.addObject("policy",policy);
		mav.setViewName("viewPolicyByUser");
		
		return mav;
	}
	
	
	@GetMapping("userHome.html")
	
	public ModelAndView getUserHome(HttpSession httpSession){
		ModelAndView modelAndView= new ModelAndView();
		System.out.println("hi from");
		List<Policy> policies = policyService.getAllPolicy();
		modelAndView.addObject("products", policies);
		System.out.println(policies);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}
	
	@RequestMapping(value="addtocart.html")
	public ModelAndView addToCart(@RequestParam("id") String policyId, HttpSession httpSession, HttpServletRequest request)
	{
		ModelAndView modelAndView= new ModelAndView();
		Policy policy= policyService.getPolicyById(policyId);
		httpSession.setAttribute("product", policy);
		li.add(policy);
		System.out.println(policy);
		modelAndView.addObject("product", policy);
		modelAndView.addObject("list", li);
		modelAndView.setViewName("cart");
		return modelAndView;
		
	}
	/*@RequestMapping(value="sortingByPolicyType")
	public ModelAndView getByPolicyType(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Policy> products = userService.getPolicyByType();
		
		modelAndView.addObject("products", products);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}
	
	@RequestMapping(value="sortingByPolicyId")
	public ModelAndView getByPolicyId(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Policy> products = userService.getPolicyById();
		
		modelAndView.addObject("products", products);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}
	
	@RequestMapping(value="sortingByNumberOfYears")
	public ModelAndView getByNumberOfYears(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Policy> products = userService.getPolicyByYears();
		
		modelAndView.addObject("products", products);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}
	
	@RequestMapping(value="sortingByCompanyName")
	public ModelAndView getByCompanyName(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Policy> products = userService.getPolicyByCompany();
		
		modelAndView.addObject("products", products);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}
	
	@RequestMapping(value="sortingByPolicyName")
	public ModelAndView getByPolicyName(HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Policy> products = userService.getPolicyByName();
		
		modelAndView.addObject("products", products);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}*/
	
	
	@RequestMapping(value="policy.html")
	public ModelAndView policy(@ModelAttribute Policy policy, HttpSession httpSession)
	{
		ModelAndView modelAndView= new ModelAndView();
		List<Policy> policies = policyService.getAllPolicy();
		modelAndView.addObject("products", policies);
		modelAndView.setViewName("userHome");
		return modelAndView;
	}
	
	
	@RequestMapping(value="search.html", method= RequestMethod.POST)
	public ModelAndView searchMedicine(@ModelAttribute Policy policy, @RequestParam("selectby") String search_by,@RequestParam("search") String search_value, HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		System.out.println(search_by);
		System.out.println(search_value);
			List<Policy> policies= policyService.searchPolicyByValues(search_by, search_value);
			modelAndView.addObject("products", policies);
			modelAndView.setViewName("userHome");
			return modelAndView;
	
	}
}
